import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'Sudety Rent | Wypożyczalnia samochodów', description: 'Wynajem samochodów w Ratnie Dolnym. Rezerwuj online.' };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pl"><body>{children}</body></html>;
}

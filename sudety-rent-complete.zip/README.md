# Sudety Rent — projekt startowy

Strona Next.js dla wypożyczalni samochodów w Ratnie Dolnym.

## Uruchomienie lokalne
Wymagany Node.js 20 lub nowszy:
1. `npm install`
2. `npm run dev`
3. Otwórz `http://localhost:3000`

## Przed publikacją
- W katalogu `public/cars/` dodaj właściwe zdjęcia każdego auta jako `1.jpg`.
- Uwaga: zdjęcia przypisane do obu Peugeotów są obecnie kopiami zdjęć Citroëna Nemo. Nie publikuj ich w ten sposób; zastąp je prawidłowymi zdjęciami.
- Uzupełnij prawdziwy telefon, e-mail, regulamin, politykę prywatności i zasady kaucji.
- Formularz na stronie jest demonstracyjny: nie tworzy rezerwacji, nie blokuje dostępności i nie pobiera płatności.
- Do uruchomienia rezerwacji potrzebny jest backend, baza danych, panel administracyjny, potwierdzenia e-mail i obsługa dostępności.
- Przelewy24 wymaga konta sprzedawcy, weryfikacji i bezpiecznej integracji po stronie serwera. Nie przechowuj sekretów w repozytorium.
- Sprawdź dane firmy, regulacje konsumenckie i RODO przed uruchomieniem komercyjnym.

## Dane floty
- Citroën Nemo 2015 — 150 zł/dzień, kaucja 500 zł
- Peugeot Bipper 2015 (egzemplarz 1) — 150 zł/dzień, kaucja 500 zł
- Hyundai i30 2010 — 150 zł/dzień, kaucja 500 zł
- Peugeot Bipper 2015 (egzemplarz 2) — 150 zł/dzień, kaucja 500 zł

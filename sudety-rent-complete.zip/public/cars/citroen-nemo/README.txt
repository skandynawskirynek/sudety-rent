Wstaw tutaj właściwe zdjęcie samochodu jako 1.jpg.

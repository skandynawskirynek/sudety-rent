# Sudety Rent — tymczasowe zdjęcia floty

Konfiguracja:
- Citroën Nemo 2015 — 150 zł/doba, kaucja 500 zł
- Peugeot Bipper 2015, egzemplarz 1 — 150 zł/doba, kaucja 500 zł
- Hyundai i30 2010 — 150 zł/doba, kaucja 500 zł, zdjęcia do dodania
- Peugeot Bipper 2015, egzemplarz 2 — 150 zł/doba, kaucja 500 zł

Miejsce odbioru: Ratno Dolne.

Na prośbę właściciela te same przesłane zdjęcia umieszczono tymczasowo przy obu Peugeotach Bipperach. Uwaga: fotografie pokazują Citroëna Nemo (widać logo Citroëna i oznaczenia), więc należy je wymienić na zdjęcia faktycznych Peugeotów przed publicznym uruchomieniem strony, aby oferta nie wprowadzała klientów w błąd.

Pakiet zawiera zdjęcia z zamaskowaną tablicą rejestracyjną. To nadal pakiet konfiguracyjny, nie gotowy produkcyjny system rezerwacji i płatności.
